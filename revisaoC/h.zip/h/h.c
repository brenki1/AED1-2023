#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(){

    char palavra[100];
    
    int i, j, cont = 0;


    printf("Insira uma palavra (string) qualquer: ");
    setbuf(stdin, NULL);
    fgets(palavra, sizeof(palavra), stdin);
    palavra[strcspn(palavra, "\n")] = '\0';

    for(i = 0; palavra[i] != '\0'; i++){
        for(j = i+1; palavra[j] != '\0'; j++){
            if(palavra[i] == palavra[j]){              
                cont++;
                printf("Existem %d letras repetidas, sendo elas %c\n", cont, palavra[i]);    
            } 
        }
        
    }

    system("pause");
    
    return 0;
}