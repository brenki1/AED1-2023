#include <stdio.h>
#include <stdlib.h>

int main(){

    int m[5][10], soma[5] = {0, 0, 0, 0, 0}, i, j;

    for(i = 0; i < 5; i++){
        for(j = 0; j < 10; j++){
            printf("Insira um valor inteiro para a posicao [%d][%d]: ", i+1, j+1);
            scanf("%d", &m[i][j]);
        }
    }

    for(i = 0; i < 5; i++){
        for(j = 0; j < 10; j++){
            soma[i] += m[i][j];

        }
    }

    for(i = 0; i < 5; i++){
        for(j = 0; j < 10; j++){
            m[i][j] *= soma[i];
        }
    }

    printf("A matriz resultante eh:\n");
    for(i = 0; i < 5; i++){
        for(j = 0; j < 10; j++){
            printf("%d ", m[i][j]);
        }
        printf("\n");
    }

    system("pause");

    return 0;
}