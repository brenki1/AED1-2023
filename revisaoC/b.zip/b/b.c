#include <stdio.h>
#include <stdlib.h>

int main(){
    
    int nascimento, atual;

    printf("Insira seu ano de nascimento e o ano atual: ");
    scanf("%d%d", &nascimento, &atual);

    printf("Atualmente, no ano de %d, sua idade eh %d ano(s), e em 2030 vc tera %d anos\n", atual, atual - nascimento, 2030 - nascimento);

    system("pause");
    return 0;
}