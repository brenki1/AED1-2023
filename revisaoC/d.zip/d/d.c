#include <stdio.h>
#include <stdlib.h>

int main(){

    int n1, n2, n3, exame = 0;
    float m, nota;

    printf("Insira suas 3 notas: ");
    scanf("%d%d%d", &n1,&n2,&n3);

    m = (n1 + n2 + n3)/3;

    if(m <= 3){
        printf("Voce esta REPROVADO!\n");
        
    } else if((m >= 3) && (m < 7)){
        printf("Voce esta de EXAME FINAL!\n");
        exame++;
    } else if(m >= 7){
        printf("Voce esta APROVADO!\n");
    }

    if(exame){
        nota = 12 - m;
        printf("Voce precisara de %f pontos no exame final para ser aprovado!\n", nota);
    }

    system("pause");

    return 0;
}