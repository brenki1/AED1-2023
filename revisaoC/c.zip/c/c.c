#include <stdio.h>
#include <stdlib.h>

int main(){
    
    char op;
    int x, y;
    float aux;

    printf("Insira o tipo de operacao aritmetica que deseja realizar (+ - * /): ");
    scanf("%c", &op);
    fflush(stdin);
    printf("Insira dois operandos: ");
    scanf("%d%d", &x, &y);
    
    switch(op){
        case('+'):
            aux = x + y;
            printf("A soma entre %d e %d eh: %f\n", x,y,aux);
            break;

        case('-'):
            aux = x - y;
            printf("A diferenca entre %d e %d eh: %f\n", x,y,aux);
            break;
        
        case('*'):
            aux = x * y;
            printf("O produto de %d e %d eh: %f\n", x,y,aux);
            break;
        
        case('/'):
            aux = x / y;
            printf("O quociente de %d e %d eh: %f\n", x,y,aux);
            break;

        default:
            printf("Operador invalido!\n");
        
    }

    system("pause");
    return 0;
}