#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct{

    char titulo[30];
    int ano;
    int paginas;
    float preco;

} livro;

int main(){

    int i, paginas = 0;
    float m;
    
    livro lvro[5];

    for(i = 0; i < 5; i++){

        printf("Insira o titulo: ");
        fgets(lvro[i].titulo, 30, stdin);
        lvro[i].titulo[strcspn(lvro[i].titulo, "\n")] = '\0';
        
        fflush(stdin);

        printf("Insira o ano: ");
        scanf("%d", &lvro[i].ano);

        printf("Insira a quantidade de paginas: ");
        scanf("%d", &lvro[i].paginas);

        printf("Insira o preco do livro: ");
        scanf("%f", &lvro[i].preco);

        fflush(stdin);
    }

    for(i = 0; i < 5; i++){
        paginas += lvro[i].paginas;
    }

    m = paginas/5;

    printf("A media de paginas eh %f\n", m);

    system("pause");
    
    return 0;
}