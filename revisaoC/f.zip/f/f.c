#include <stdio.h>
#include <stdlib.h>

int main(){

    float b, h, a;

    printf("Insira a base e altura de um triangulo qualquer: ");
    scanf("%f%f", &b, &h);

    if((b <= 0) || (h <= 0)){
        printf("Numeros invalidos! Por favor digite medidas maiores que 0.\n");
        return 0;
    }

    a = (b*h)/2;

    printf("A area desse triangulo eh %f", a);

    system("pause");

    return 0;
}