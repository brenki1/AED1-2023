#include <stdio.h>
#include <stdlib.h>

int main(){

    int menor = 0, soma, i, x;

    for(i = 0; i < 10; i++){
        printf("Digite um numero: ");
        scanf("%d", &x);

        if(x > 10){
            soma += x;
        } else if(x < 10){
            menor++;
        }
    }

    printf("A soma dos numeros maiores que 10 eh %d\ne %d numero(s) sao menores que 10\n", soma, menor);

    system("pause");

    return 0;

}